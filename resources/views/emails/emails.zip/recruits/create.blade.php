<h1>you receive a new work application </h1>

<p>Name = {{$name}}</p>
<p>Address={{$home_address}}</p>
<p>email = {{$personal_email}}</p>
<p>phone ={{$mobile_phone_number}}</p>
